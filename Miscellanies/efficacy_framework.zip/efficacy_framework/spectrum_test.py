"""
谱形检验脚本：区分「几何（等比）谱」与「幂律谱」，并核对论证中的三个解析结论。

核对项：
  T1  能量守恒  ||X||^2 = ||Y||^2 + ||S||^2   （SVD 截断的正交性）
  T3  等比谱 e_i = q^i  => 每层能量占比 a = 1 - q^r 恒定
  T4  有效层数  H_eps = ln(1/eps) / (-ln(1-a))

检验项：
  E1  在 log e 上分别拟合  exp: log e = c - lam*i   与   pow: log e = c - alpha*log(i+1)
  E2  固定 r=1 逐层计算 a_k，看变异系数 CV（几何谱应接近 0，幂律谱应明显大于 0）
  E3  随机高斯矩阵作为零模型（谱应两者都拟合不好）
"""
import numpy as np

rng = np.random.default_rng(0)
M, N = 200, 150
K = min(M, N)


def make_matrix(e, noise=0.0):
    """按给定能量谱 e 构造矩阵：随机正交基 + 可选高斯噪声。"""
    U, _ = np.linalg.qr(rng.standard_normal((M, K)))
    V, _ = np.linalg.qr(rng.standard_normal((N, K)))
    X = (U * np.sqrt(e)) @ V.T
    if noise > 0:
        X = X + noise * rng.standard_normal((M, N))
    return X


def spectrum(X):
    s = np.linalg.svd(X, compute_uv=False)
    return s ** 2


def fit_models(e, i_max):
    idx = np.arange(i_max)
    y = np.log(e[:i_max])
    tss = np.sum((y - y.mean()) ** 2)

    A = np.vstack([np.ones(i_max), idx]).T
    c1, *_ = np.linalg.lstsq(A, y, rcond=None)
    rss_exp = np.sum((y - A @ c1) ** 2)

    B = np.vstack([np.ones(i_max), np.log(idx + 1.0)]).T
    c2, *_ = np.linalg.lstsq(B, y, rcond=None)
    rss_pow = np.sum((y - B @ c2) ** 2)

    return {
        "q_hat": float(np.exp(c1[1])),
        "alpha_hat": float(-c2[1]),
        "R2_exp": 1 - rss_exp / tss,
        "R2_pow": 1 - rss_pow / tss,
        "decades": (y.max() - y.min()) / np.log(10),
        "winner": "exp(几何)" if rss_exp < rss_pow else "pow(幂律)",
    }


def level_shares(e, r=1, levels=20):
    """固定每层 r 个分量，逐层计算该层能量 / 当前残差能量。"""
    shares = []
    for k in range(levels):
        tail = e[k * r:].sum()
        shares.append(e[k * r:(k + 1) * r].sum() / tail)
    return np.array(shares)


def level_profile(e, r=1, floor=1e-3):
    """逐层占比 a_k，直到残差能量占比低于 floor。
    不能只看前几层：随机矩阵谱的头部近乎平坦，前几层的 a_k 看起来也近似常数。"""
    total = e.sum()
    shares = []
    k = 0
    while (k + 1) * r <= len(e):
        tail = e[k * r:].sum()
        if tail / total < floor:
            break
        shares.append(e[k * r:(k + 1) * r].sum() / tail)
        k += 1
    return np.array(shares)


def report(name, e, i_max, floor=1e-3):
    f = fit_models(e, i_max)
    a = level_profile(e, r=1, floor=floor)
    cv = a.std() / a.mean()
    reasons = []
    if f["R2_exp"] < 0.99:
        reasons.append(f"R2(几何)={f['R2_exp']:.3f}<0.99")
    if f["decades"] < 3:
        reasons.append(f"跨度{f['decades']:.1f}<3个数量级")
    if cv > 0.05:
        reasons.append(f"a_k变异系数{cv:.3f}>0.05")
    verdict = "支持几何谱" if not reasons else "不支持几何谱（" + "；".join(reasons) + "）"
    print(f"[{name}]")
    print(f"  拟合区间 i<{i_max}，跨 {f['decades']:.1f} 个数量级")
    print(f"  R2(几何)={f['R2_exp']:.4f}  R2(幂律)={f['R2_pow']:.4f}  => 较优模型：{f['winner']}")
    print(f"  q_hat={f['q_hat']:.4f}  alpha_hat={f['alpha_hat']:.3f}")
    print(f"  r=1 逐层占比 a_k（共{len(a)}层，残差>{floor:g}）: 首项={a[0]:.4f} 末项={a[-1]:.4f} CV={cv:.3f}")
    print(f"  判定：{verdict}")
    print()
    return f, a


def main():
    idx = np.arange(K)

    # ---- 几何谱（含噪声，用 MP 上沿 4 倍作截断）----
    q = 0.9
    noise = 1e-4
    e_geo = q ** idx
    X_geo = make_matrix(e_geo, noise=noise)
    edge = noise ** 2 * (np.sqrt(M) + np.sqrt(N)) ** 2
    es = spectrum(X_geo)
    i_max = int(np.sum(es > 4 * edge))
    report("几何谱 q=0.9 + 噪声", es, i_max)

    # ---- 幂律谱 ----
    alpha = 1.5
    e_pow = (idx + 1.0) ** (-alpha)
    X_pow = make_matrix(e_pow)
    es_pow = spectrum(X_pow)
    report("幂律谱 alpha=1.5", es_pow, K)

    # ---- 随机高斯（零模型）----
    X_rnd = rng.standard_normal((M, N))
    es_rnd = spectrum(X_rnd)
    report("随机高斯矩阵（零模型）", es_rnd, K)

    # ---- T1：能量守恒 ----
    U, s, Vt = np.linalg.svd(X_pow, full_matrices=False)
    r = 5
    Y = (U[:, :r] * s[:r]) @ Vt[:r]
    S = X_pow - Y
    lhs = np.linalg.norm(X_pow, "fro") ** 2
    rhs = np.linalg.norm(Y, "fro") ** 2 + np.linalg.norm(S, "fro") ** 2
    cross = np.sum(Y * S)
    print("[T1 能量守恒]")
    print(f"  ||X||^2={lhs:.10f}  ||Y||^2+||S||^2={rhs:.10f}  交叉项<Y,S>={cross:.2e}")
    print()

    # ---- T3/T4：几何谱的 a 与有效层数 ----
    q = 0.9
    e = q ** idx
    for r in (1, 3):
        a_theory = 1 - q ** r
        a_emp = level_shares(e, r=r, levels=10)
        print(f"[T3 r={r}] 理论 a=1-q^r={a_theory:.4f}  经验 a_k 均值={a_emp.mean():.4f} CV={a_emp.std()/a_emp.mean():.2e}")
    a = 1 - q
    eps = 1e-6
    H_formula = np.log(1 / eps) / (-np.log(1 - a))
    resid = np.array([e[k:].sum() / e.sum() for k in range(K)])
    H_emp = int(np.argmax(resid < eps))
    print(f"[T4 有效层数 r=1, eps={eps:g}] 公式={H_formula:.1f}  数值首次低于 eps 的层={H_emp}  rank 上界={K}")


def block_mean(X, size):
    """对行做块平均（块大小 size），再广播回原形状：即投影到「块内常数」的子空间。"""
    m = X.shape[0]
    return np.repeat(X.reshape(m // size, size, -1).mean(axis=1), size, axis=0)


def make_selfsimilar(m, n, nu, b=2):
    """嵌套聚合下的构造：第 l 层细节的每自由度能量 v_l = nu**l；nu=1 即白噪声。"""
    L = int(round(np.log(m) / np.log(b)))
    X = block_mean(rng.standard_normal((m, n)), m) * np.sqrt(nu ** L)
    for l in range(L):
        Z = rng.standard_normal((m, n))
        X = X + (block_mean(Z, b ** l) - block_mean(Z, b ** (l + 1))) * np.sqrt(nu ** l)
    return X


def nested_checks(m=256, n=40, b=2):
    """尺度轴（嵌套聚合）检验。只依赖 X 本身重新分解，不使用构造时的参数。"""
    L = int(round(np.log(m) / np.log(b)))
    dof = np.array([m * (b - 1) // b ** (l + 1) for l in range(L)])
    print("=" * 60)
    print(f"嵌套聚合（尺度轴）检验：m={m} 个单位，分支数 b={b}，层深 L={L}")
    print(f"各层细节的自由度 dof_l = {dof.tolist()}（总和 + 根 1 = {int(dof.sum()) + 1}）")
    print("=" * 60)
    for name, nu in (("白噪声 nu=1", 1.0), ("自相似 nu=1.5", 1.5), ("自相似 nu=0.7", 0.7)):
        X = make_selfsimilar(m, n, nu, b)
        E = np.linalg.norm(X, "fro") ** 2
        root = block_mean(X, m)
        details = [block_mean(X, b ** l) - block_mean(X, b ** (l + 1)) for l in range(L)]
        E_root = np.linalg.norm(root, "fro") ** 2
        E_lv = np.array([np.linalg.norm(D, "fro") ** 2 for D in details])

        gap = abs(E - (E_root + E_lv.sum()))
        v = E_lv / (dof * n)
        k = 6  # 最粗的几层自由度太少、噪声大，只看前 k 对相邻层
        ratio_E = E_lv[1:] / E_lv[:-1]
        ratio_v = v[1:] / v[:-1]

        vis = [np.linalg.norm(block_mean(X, b ** l), "fro") ** 2 / E for l in range(L + 1)]
        mono = all(vis[i] >= vis[i + 1] - 1e-12 for i in range(len(vis) - 1))
        l_obs = 3
        leak = max(np.linalg.norm(block_mean(details[j], b ** l_obs), "fro") for j in range(l_obs))

        total = E_root
        for D in details:
            U, s, Vt = np.linalg.svd(D, full_matrices=False)
            Y = s[0] * np.outer(U[:, 0], Vt[0])
            S = D - Y
            total += np.linalg.norm(Y, "fro") ** 2 + np.linalg.norm(S, "fro") ** 2

        print(f"[{name}]")
        print(f"  N1 嵌套守恒 |E - (E_root + ΣE_l)| = {gap:.2e}")
        print(f"  相邻层能量比 E_(l+1)/E_l（前{k}对均值）= {ratio_E[:k].mean():.3f}，理论 nu/b = {nu / b:.3f}")
        print(f"  相邻层每自由度能量比 nu_hat（前{k}对均值）= {ratio_v[:k].mean():.3f}，理论 nu = {nu:.3f}")
        print("  观察者在层级 l=0..%d 的可见能量占比: " % L + " ".join(f"{x:.3f}" for x in vis))
        print(f"  可见能量随层级变粗单调不增: {mono}；层级{l_obs}观察者对更细细节的泄漏 = {leak:.2e}")
        print(f"  两轴合并守恒 |E - Σ(‖Y‖²+‖S‖²)|（每层 r=1 截断，显式矩阵）= {abs(E - total):.2e}")
        print()


if __name__ == "__main__":
    main()
    print()
    nested_checks()
