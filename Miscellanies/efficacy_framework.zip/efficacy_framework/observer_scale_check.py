"""
观察者与尺度检验（对应 v0.5 第 11 节与 v0.6 第 12 节）。五部分都是合成构造，只验证规则与记账，不是现实证据。

part 1  欠拟合与过拟合：观察者选择秩 r，真实秩 N=5，距离 M = r - N（负=欠拟合，正=过拟合）。
        误差 = 对真值（无噪声信号）的相对误差，用留出行计算。
part 2  观测单位数 P 与可见分量数 D：D(P) 是否等于 min(N, P)（"D 随 P 等比例"）。
part 3  粗粒化下峰数是否增加（对应 A10："C 会增加 N 层属性"）：高斯平滑与块平均两种粗粒化。
part 4  层数的两种计法（v0.6 第 12 节）：聚合层数 Z_agg 与可见细节层数 Z_vis；以及粗粒化对可见秩上限的影响。
part 5  E_g 的候选定义（v0.6 第 12 节）：M - |T| 与 |M| - |T| 在欠拟合/过拟合区间的符号，对照留出误差。
"""
import numpy as np

rng = np.random.default_rng(2026)
W = np.array([0.40, 0.35, 0.30, 0.25, 0.22])  # 5 个信号分量的强度


def make_signal(m, n):
    L = rng.standard_normal((m, len(W))) * W
    R = rng.standard_normal((n, len(W)))
    return L @ R.T


# ---------------- part 1 ----------------
def part1(trials=30, m=400, n=100, sigma=1.0, N=5):
    ranks = list(range(0, 11))
    held = {r: [] for r in ranks}
    ins = {r: [] for r in ranks}
    for _ in range(trials):
        X0 = make_signal(m, n)
        X = X0 + sigma * rng.standard_normal((m, n))
        tr, te = slice(0, m // 2), slice(m // 2, m)
        _, _, Vt = np.linalg.svd(X[tr], full_matrices=False)
        for r in ranks:
            Vr = Vt[:r].T
            ins[r].append(np.linalg.norm(X[tr] - X[tr] @ Vr @ Vr.T) ** 2 / np.linalg.norm(X[tr]) ** 2)
            held[r].append(np.linalg.norm(X0[te] - X[te] @ Vr @ Vr.T) ** 2 / np.linalg.norm(X0[te]) ** 2)
    print("[part 1] 欠拟合与过拟合（真实秩 N=5，噪声 sigma=1，30 次平均）")
    print("   r   M=r-N   训练集拟合残差   对真值的留出误差")
    for r in ranks:
        print(f"  {r:2d}   {r - N:+3d}      {np.mean(ins[r]):.4f}          {np.mean(held[r]):.4f}")
    best = min(ranks, key=lambda r: np.mean(held[r]))
    print(f"  留出误差最小的 r = {best}（M = {best - N:+d}）")
    # 不对称：偏离同样的 |M| 时，欠拟合与过拟合的误差
    for d in (1, 2, 3):
        under = np.mean(held[N - d]) - np.mean(held[N])
        over = np.mean(held[N + d]) - np.mean(held[N])
        print(f"  |M|={d}：欠拟合比最优多出误差 {under:.4f}；过拟合比最优多出误差 {over:.4f}")
    print()


# ---------------- part 2 ----------------
def part2(trials=20, n=100, sigma=1.0, label="", w_scale=1.0):
    Ps = [2, 3, 4, 5, 6, 8, 10, 15, 20, 40, 100, 400]
    row = []
    for P in Ps:
        cnt = []
        for _ in range(trials):
            L = rng.standard_normal((P, len(W))) * W * w_scale
            R = rng.standard_normal((n, len(W)))
            X = L @ R.T + sigma * rng.standard_normal((P, n))
            e = np.linalg.svd(X, compute_uv=False) ** 2
            edge = sigma ** 2 * (np.sqrt(P) + np.sqrt(n)) ** 2
            cnt.append(int(np.sum(e > 1.15 * edge)))
        row.append(np.mean(cnt))
    print(f"[part 2] {label}：观测单位数 P 与可见分量数 D（真实秩 N=5，20 次平均）")
    print("  P       " + " ".join(f"{p:5d}" for p in Ps))
    print("  D(P)    " + " ".join(f"{d:5.1f}" for d in row))
    print("  min(N,P)" + " ".join(f"{min(5, p):5d}" for p in Ps))
    print()


# ---------------- part 3 ----------------
def gauss_smooth(x, s):
    k = int(4 * s) + 1
    t = np.arange(-k, k + 1)
    ker = np.exp(-t ** 2 / (2 * s ** 2))
    ker /= ker.sum()
    xp = np.pad(x, k, mode="reflect")
    return np.convolve(xp, ker, mode="valid")


def n_max(x):
    return int(np.sum((x[1:-1] > x[:-2]) & (x[1:-1] > x[2:])))


def block_mean(x, b):
    return x[: len(x) // b * b].reshape(-1, b).mean(axis=1)


def part3(n_sig=500, length=512):
    scales = [1, 2, 4, 8, 16, 32]
    kinds = {"白噪声": lambda: rng.standard_normal(length),
             "随机游走": lambda: np.cumsum(rng.standard_normal(length))}
    print("[part 3] 粗粒化下峰数是否增加（每种 500 条信号，长度 512，尺度 1,2,4,8,16,32）")
    for kname, gen in kinds.items():
        v_g = v_b = 0
        inc_g = inc_b = 0
        tot_steps = 0
        for _ in range(n_sig):
            x = gen()
            cg = [n_max(gauss_smooth(x, s)) if s > 1 else n_max(x) for s in scales]
            cb = [n_max(block_mean(x, s)) for s in scales]
            if any(cg[i + 1] > cg[i] for i in range(len(scales) - 1)):
                v_g += 1
            if any(cb[i + 1] > cb[i] for i in range(len(scales) - 1)):
                v_b += 1
            inc_g += sum(cg[i + 1] > cg[i] for i in range(len(scales) - 1))
            inc_b += sum(cb[i + 1] > cb[i] for i in range(len(scales) - 1))
            tot_steps += len(scales) - 1
        print(f"  {kname}：高斯平滑——出现过峰数增加的信号 {v_g}/{n_sig}（升高的步数 {inc_g}/{tot_steps}）；"
              f"块平均——{v_b}/{n_sig}（{inc_b}/{tot_steps}）")
    print()


# ---------------- part 4 ----------------
def bmean2(X, size):
    """对行做块平均再广播回原形状（= 投影 P_l，块大小 size = b**l）。"""
    m = X.shape[0]
    return np.repeat(X.reshape(m // size, size, -1).mean(axis=1), size, axis=0)


def part4(m=256, n=40, b=2, tol=1e-9):
    """观察者位于层级 l（l 越大越粗，对应 C 增加）时只看到 P_l X。
    Z_agg = l：被聚合掉的层数；Z_vis = 在 P_l X 中仍有能量的细节层数（应为 lmax - l，lmax 为嵌套深度）。
    同时报告行秩上限 min(m/b^l, n)：粗粒化会压低观察者可能看到的秩。"""
    lmax = int(round(np.log(m) / np.log(b)))  # 嵌套深度（v0.2 记 L；v0.6 起记 ℓ_max，L 留给"微观层级"）
    X = rng.standard_normal((m, n))  # 白噪声：每层细节都有能量
    print(f"[part 4] 层数的两种计法（m={m}，b={b}，嵌套深度 lmax={lmax}，n={n}）")
    print("   l   Z_agg=l   Z_vis(数值)   lmax-l   观察者所见行数 m/b^l   rank(P_l X)   min(m/b^l, n)")
    ok = True
    for l in range(lmax + 1):
        Y = bmean2(X, b ** l)
        E = np.linalg.norm(Y, "fro") ** 2
        z_vis = 0
        for j in range(lmax):
            Dj = bmean2(Y, b ** j) - bmean2(Y, b ** (j + 1))
            if np.linalg.norm(Dj, "fro") ** 2 > tol * E:
                z_vis += 1
        rk = int(np.linalg.matrix_rank(Y))
        cap = min(m // b ** l, n)
        ok &= (z_vis == lmax - l) and (rk == cap)
        print(f"  {l:2d}    {l:2d}        {z_vis:2d}          {lmax - l:2d}           {m // b ** l:4d}"
              f"                {rk:3d}           {cap:3d}")
    print(f"  Z_vis == lmax - l 且 rank == min(m/b^l, n) 在所有层成立：{ok}")
    print()


# ---------------- part 5 ----------------
def part5(trials=30, m=400, n=100, sigma=1.0, N=5, rmax=20):
    """E_g 的两个候选：E1 = M - |T|（M 带符号），E2 = |M| - |T|。取 |T| = N（峰数等于真实秩，即 M0 成立时）。"""
    ranks = list(range(0, rmax + 1))
    held = {r: [] for r in ranks}
    for _ in range(trials):
        X0 = make_signal(m, n)
        X = X0 + sigma * rng.standard_normal((m, n))
        tr, te = slice(0, m // 2), slice(m // 2, m)
        _, _, Vt = np.linalg.svd(X[tr], full_matrices=False)
        for r in ranks:
            Vr = Vt[:r].T
            held[r].append(np.linalg.norm(X0[te] - X[te] @ Vr @ Vr.T) ** 2 / np.linalg.norm(X0[te]) ** 2)
    best = min(ranks, key=lambda r: np.mean(held[r]))
    print(f"[part 5] E_g 的候选定义（系统常量 Q={N}＝真实秩；取 |T|=Q，即峰数等于 Q；J=r；M=J-Q；30 次平均；代码里 Q 记作 N）")
    print("   J=r   M    E1=M-|T|   E2=|M|-|T|   留出误差   相对最优多出")
    for r in ranks:
        M = r - N
        e = np.mean(held[r])
        print(f"  {r:3d}  {M:+3d}    {M - N:+4d}       {abs(M) - N:+4d}        {e:.4f}      {e - np.mean(held[best]):+.4f}")
    pos1 = [r for r in ranks if r - N - N > 0]
    pos2 = [r for r in ranks if abs(r - N) - N > 0]
    print(f"  E1>0 的 J：{pos1[:1] and f'{pos1[0]}..{pos1[-1]}' or '无'}；E2>0 的 J：{pos2[:1] and f'{pos2[0]}..{pos2[-1]}' or '无'}；"
          f"留出误差最优的 J={best}")
    if pos1:
        print(f"  E1>0 区间内留出误差均高于最优：{all(np.mean(held[r]) > np.mean(held[best]) for r in pos1)}；"
              f"该区间内留出误差随 J 单调上升：{all(np.mean(held[pos1[i + 1]]) >= np.mean(held[pos1[i]]) for i in range(len(pos1) - 1))}")
    print()


if __name__ == "__main__":
    part1()
    part2(sigma=0.1, label="强信号（sigma=0.1）")
    part2(sigma=1.0, label="弱信号（sigma=1.0）")
    part3()
    part4()
    part5()
