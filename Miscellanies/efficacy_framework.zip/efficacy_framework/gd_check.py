"""核对：最优秩 J* 是否等于真实秩 Q？弱分量存在时 J* < Q（Gavish–Donoho 阈值的含义）。合成数据，种子固定。"""
import numpy as np
rng = np.random.default_rng(2026)

def lam_star(beta):  # Gavish–Donoho: 已知噪声 sigma，m×n（beta=m/n<=1）的最优硬阈值系数
    return np.sqrt(2*(beta+1) + 8*beta/((beta+1) + np.sqrt(beta**2 + 14*beta + 1)))

def run(W, trials=40, m=400, n=100, sigma=1.0, rmax=12):
    W = np.array(W); Q = len(W)
    ranks = list(range(rmax + 1))
    held = {r: [] for r in ranks}; n_above = []
    mt = m // 2
    tau = lam_star(n / mt) * np.sqrt(mt) * sigma
    for _ in range(trials):
        L = rng.standard_normal((m, Q)) * W; R = rng.standard_normal((n, Q))
        X0 = L @ R.T; X = X0 + sigma * rng.standard_normal((m, n))
        tr, te = slice(0, mt), slice(mt, m)
        _, s, Vt = np.linalg.svd(X[tr], full_matrices=False)
        n_above.append(int((s > tau).sum()))
        for r in ranks:
            Vr = Vt[:r].T
            held[r].append(np.linalg.norm(X0[te] - X[te] @ Vr @ Vr.T) ** 2 / np.linalg.norm(X0[te]) ** 2)
    mean = {r: np.mean(held[r]) for r in ranks}
    best = min(ranks, key=lambda r: mean[r])
    return Q, best, np.mean(n_above), tau, mean

for name, W in (("五个分量都较强 W=[.40,.35,.30,.25,.22]", [0.40, 0.35, 0.30, 0.25, 0.22]),
                ("后两个很弱   W=[.40,.35,.30,.12,.08]", [0.40, 0.35, 0.30, 0.12, 0.08])):
    Q, best, nab, tau, mean = run(W)
    print(f"{name}: Q={Q}  留出误差最优的 r={best}  训练矩阵奇异值高于 GD 阈值({tau:.1f}) 的个数(均值)={nab:.2f}")
    print("   r:      " + " ".join(f"{r:6d}" for r in range(0, 9)))
    print("   留出误差 " + " ".join(f"{mean[r]:6.3f}" for r in range(0, 9)))
