"""A2 的注意点：奇异值谱看不见"效能不对称"。
构造一条左偏的不对称峰（慢升快降）a，取秩一矩阵 X = a b^T；再取 a 的镜像（行反转）。
行的任何置换（含反转）都不改变奇异值，所以不对称曲线与其镜像的谱完全相同。
"""
import numpy as np

rng = np.random.default_rng(3)
t = np.linspace(0, 1, 200)
asym = np.where(t < 0.7, (t / 0.7) ** 2, np.exp(-((t - 0.7) / 0.08) ** 2))  # 慢升快降
b = rng.standard_normal(40)
X = np.outer(asym, b)
Xm = np.outer(asym[::-1], b)  # 镜像
s, sm = np.linalg.svd(X, compute_uv=False), np.linalg.svd(Xm, compute_uv=False)
def skewness(w):
    mu = np.average(t, weights=w)
    m2 = np.average((t - mu) ** 2, weights=w)
    return np.average((t - mu) ** 3, weights=w) / m2 ** 1.5


print(f"曲线的偏度：{skewness(asym):+.3f}；镜像后：{skewness(asym[::-1]):+.3f}（符号相反，说明确实不对称）")
print(f"前 3 个奇异值 原：{s[:3].round(6)}  镜像：{sm[:3].round(6)}")
print(f"两组奇异值最大差 = {np.max(np.abs(s - sm)):.2e}；显著分量数（> 1e-8）：{int((s > 1e-8).sum())} 与 {int((sm > 1e-8).sum())}")
