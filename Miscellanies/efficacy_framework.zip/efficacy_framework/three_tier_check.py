"""
三层谱检验：把 S 拆成 Y（间接有效）与 U（非有效），与 V（直接有效）合成 V | Y | U 三层。

操作化定义（脚本里事先固定）：
  U 层  : 能量不超过 mult * MP 上沿 的分量（噪声级）。MP 上沿 = sigma^2 (sqrt(m)+sqrt(n))^2，
          这里 sigma 已知；真实数据里 sigma 未知，是局限。
  V|Y 界: 在信号分量（高于噪声）里，取相邻能量比最大的位置；最大比 < 3 视为「无谱隙，界未定义」。

检验：
  C1  三层能量守恒与两两正交
  C2  各层每分量平均能量按层递减
  C3  层界是否稳定：  场景 A（有谱隙）  vs  场景 B（几何谱，无谱隙）
"""
import numpy as np

rng = np.random.default_rng(7)
m, n = 200, 150
SIGMA = 0.05
EDGE = SIGMA ** 2 * (np.sqrt(m) + np.sqrt(n)) ** 2


def build(e_signal):
    r = len(e_signal)
    U, _ = np.linalg.qr(rng.standard_normal((m, r)))
    V, _ = np.linalg.qr(rng.standard_normal((n, r)))
    return (U * np.sqrt(e_signal)) @ V.T + SIGMA * rng.standard_normal((m, n))


def tiers(e, mult=1.15, gap_min=3.0):
    thr = mult * EDGE
    n_sig = int(np.sum(e > thr))
    if n_sig < 2:
        return n_sig, None, len(e) - n_sig
    ratios = e[:n_sig - 1] / e[1:n_sig]
    pos = int(np.argmax(ratios))
    n_v = pos + 1 if ratios[pos] >= gap_min else None
    return n_sig, n_v, len(e) - n_sig, float(ratios[pos])


def report_block(name, X, planted=None):
    Uu, s, Vt = np.linalg.svd(X, full_matrices=False)
    e = s ** 2
    n_sig, n_v, n_u, *rest = tiers(e)
    gap = rest[0] if rest else float("nan")
    print(f"[{name}]")
    if planted:
        print(f"  构造：V 层 {planted[0]} 个，Y 层 {planted[1]} 个；噪声 sigma={SIGMA}，MP 上沿={EDGE:.3f}")
    print(f"  检出：信号分量 {n_sig} 个，U 层 {n_u} 个；信号内最大相邻能量比 {gap:.2f}"
          f" -> V 层 {n_v if n_v is not None else '未定义（无谱隙）'}")
    if n_v is None:
        return e, None
    nY = n_sig - n_v
    blocks = {"V": slice(0, n_v), "Y": slice(n_v, n_sig), "U": slice(n_sig, len(e))}
    mats = {k: (Uu[:, sl] * s[sl]) @ Vt[sl] for k, sl in blocks.items()}
    E = np.linalg.norm(X, "fro") ** 2
    Ek = {k: np.linalg.norm(M, "fro") ** 2 for k, M in mats.items()}
    cross = max(abs(np.sum(mats["V"] * mats["Y"])), abs(np.sum(mats["V"] * mats["U"])),
                abs(np.sum(mats["Y"] * mats["U"])))
    cnt = {"V": n_v, "Y": nY, "U": n_u}
    mean = {k: Ek[k] / cnt[k] for k in cnt}
    print(f"  C1 能量守恒 |E-(E_V+E_Y+E_U)|={abs(E - sum(Ek.values())):.2e}；两两交叉项最大值={cross:.2e}")
    for k in ("V", "Y", "U"):
        print(f"     {k} 层：{cnt[k]:3d} 个分量（数量占比 {cnt[k] / len(e):.3f}），能量占比 {Ek[k] / E:.4f}，每分量平均能量 {mean[k]:.3f}")
    print(f"  C2 每分量平均能量递减 V>Y>U : {mean['V'] > mean['Y'] > mean['U']}")
    return e, cnt


def stability(name, e):
    print(f"  C3 [{name}] 信号分量个数随噪声阈值倍数 mult 的变化：")
    out = []
    for mult in (1.0, 1.15, 1.5, 2.0, 3.0, 5.0):
        out.append((mult, int(np.sum(e > mult * EDGE))))
    print("     " + "  ".join(f"mult={a:g}->{b}" for a, b in out))
    counts = [b for _, b in out]
    print(f"     最大/最小 = {max(counts)}/{min(counts)}")


def main():
    print(f"矩阵 {m}x{n}，MP 上沿 = {EDGE:.3f}\n")

    # 场景 A：三层各自成块，层间有谱隙
    eV = np.array([400.0, 250.0, 150.0])
    eY = np.linspace(20.0, 12.0, 8)
    XA = build(np.concatenate([eV, eY]))
    eA, _ = report_block("场景 A：有谱隙（V 3 个，Y 8 个，其余噪声）", XA, planted=(3, 8))
    stability("A", eA)
    print()

    # 场景 B：几何谱 100*0.9^i，无谱隙
    eB_sig = 100.0 * 0.9 ** np.arange(m if m < n else n)
    XB = build(eB_sig)
    eB, _ = report_block("场景 B：几何谱 100*0.9^i（无谱隙）", XB)
    stability("B", eB)
    sig = eB[eB > 1.15 * EDGE]
    print(f"     信号内相邻能量比范围 {np.min(sig[:-1] / sig[1:]):.3f} ~ {np.max(sig[:-1] / sig[1:]):.3f}")


if __name__ == "__main__":
    main()
