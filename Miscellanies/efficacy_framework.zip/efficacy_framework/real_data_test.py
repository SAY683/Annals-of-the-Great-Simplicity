"""
真实数据检验（模式轴）：BCI 物种 x 样地计数矩阵。
判据与整体标签的规则见 preregistration_BCI.md（运行前已固定）。

用法：python3 -I real_data_test.py <BCI.rda 路径>
"""
import sys
import numpy as np
import pyreadr

rng = np.random.default_rng(20261106)
N_PERM = 200
FLOOR = 1e-3


# ---------- 与 spectrum_test.py 相同的拟合与逐层占比（复制，便于独立运行） ----------
def fit_models(e, i_max):
    idx = np.arange(i_max)
    y = np.log(e[:i_max])
    tss = np.sum((y - y.mean()) ** 2)
    A = np.vstack([np.ones(i_max), idx]).T
    c1, *_ = np.linalg.lstsq(A, y, rcond=None)
    rss_exp = np.sum((y - A @ c1) ** 2)
    B = np.vstack([np.ones(i_max), np.log(idx + 1.0)]).T
    c2, *_ = np.linalg.lstsq(B, y, rcond=None)
    rss_pow = np.sum((y - B @ c2) ** 2)
    return {
        "q_hat": float(np.exp(c1[1])),
        "alpha_hat": float(-c2[1]),
        "R2_exp": 1 - rss_exp / tss,
        "R2_pow": 1 - rss_pow / tss,
        "decades": (y.max() - y.min()) / np.log(10),
    }


def level_profile(e, r=1, floor=FLOOR):
    total = e.sum()
    shares = []
    k = 0
    while (k + 1) * r <= len(e):
        tail = e[k * r:].sum()
        if tail / total < floor:
            break
        shares.append(e[k * r:(k + 1) * r].sum() / tail)
        k += 1
    return np.array(shares)


# ---------- 表示族 ----------
def represent(name, raw):
    if name == "R1 原始计数":
        return raw
    if name == "R2 log(1+x)":
        return np.log1p(raw)
    if name == "R3 Hellinger":
        p = raw / raw.sum(axis=1, keepdims=True)
        return np.sqrt(p)
    if name == "R4 列标准化":
        sd = raw.std(axis=0, ddof=1)
        keep = sd > 0
        return (raw[:, keep] - raw[:, keep].mean(axis=0)) / sd[keep]
    raise ValueError(name)


REPS = ["R1 原始计数", "R2 log(1+x)", "R3 Hellinger", "R4 列标准化"]


def energies(X):
    s = np.linalg.svd(X, compute_uv=False)
    s = s[s > 1e-10 * s[0]]
    return s ** 2


def evaluate(e):
    f = fit_models(e, len(e))
    a = level_profile(e, r=1, floor=FLOOR)
    cv = float(a.std() / a.mean()) if len(a) >= 3 else float("nan")
    return f, cv, len(a)


def is_geo_criteria(f, cv):
    return (f["R2_exp"] >= 0.99) and (f["decades"] >= 3) and (cv == cv and cv <= 0.05)


def is_pow_criteria(f):
    return (f["R2_pow"] >= 0.99) and (f["R2_pow"] - f["R2_exp"] >= 0.05)


def main(path):
    raw = pyreadr.read_r(path)["BCI"].values.astype(float)
    print(f"矩阵：{raw.shape[0]} 个样地 x {raw.shape[1]} 个物种，总株数 {int(raw.sum())}")
    print()

    verdicts = []
    for name in REPS:
        X = represent(name, raw)
        e = energies(X)
        f, cv, n_lv = evaluate(e)

        r2_null = []
        geo_pass_null = 0
        for _ in range(N_PERM):
            P = rng.permuted(raw, axis=0)  # 每个物种列独立置换样地顺序
            en = energies(represent(name, P))
            fn, cvn, _ = evaluate(en)
            r2_null.append(fn["R2_exp"])
            geo_pass_null += int(is_geo_criteria(fn, cvn))
        r2_null = np.array(r2_null)
        q975 = float(np.quantile(r2_null, 0.975))
        beats_null = f["R2_exp"] > q975

        geo = is_geo_criteria(f, cv)
        powl = is_pow_criteria(f)
        if geo and beats_null:
            v = "几何"
        elif powl:
            v = "幂律"
        elif f["decades"] < 3:
            v = "不可判定"
        else:
            v = "皆不"
        verdicts.append(v)

        print(f"[{name}] 有效奇异值 {len(e)} 个")
        print(f"  谱跨度 {f['decades']:.2f} 个数量级；前 4 个归一化能量 = "
              + " ".join(f"{x:.4f}" for x in (e / e.sum())[:4]))
        print(f"  R2(几何)={f['R2_exp']:.4f}  R2(幂律)={f['R2_pow']:.4f}  q_hat={f['q_hat']:.4f}  alpha_hat={f['alpha_hat']:.3f}")
        print(f"  r=1 逐层占比 a_k：共 {n_lv} 层，CV={cv:.3f}")
        print(f"  零模型（{N_PERM} 次列置换）R2(几何) 97.5 分位={q975:.4f}；零模型通过几何判据的比例={geo_pass_null / N_PERM:.3f}")
        print(f"  几何判据={'通过' if geo else '未通过'}；超出零模型={'是' if beats_null else '否'}；幂律判据={'通过' if powl else '未通过'}")
        print(f"  单项判定：{v}")
        print()

    n_geo = verdicts.count("几何")
    n_pow = verdicts.count("幂律")
    n_ind = verdicts.count("不可判定")
    if n_geo >= 3:
        overall = "几何谱成立"
    elif n_pow >= 3:
        overall = "幂律成立"
    elif n_ind >= 3:
        overall = "不可判定"
    elif n_geo == 0 and n_pow == 0:
        overall = "两者皆不"
    else:
        overall = "依赖表示"
    print("各表示判定：", dict(zip(REPS, verdicts)))
    print(f"整体标签（按预先登记规则）：{overall}")


if __name__ == "__main__":
    main(sys.argv[1])
