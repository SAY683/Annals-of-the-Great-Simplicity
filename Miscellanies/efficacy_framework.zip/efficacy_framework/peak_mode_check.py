"""
M0 检验：一个峰是否对应一个秩一模式？
构造 3 个已知的高斯峰，数奇异值谱里高于噪声上沿的显著分量个数，与峰数 N=3 比较。

三种情形：
  (a) 可分离峰、位置分开
  (b) 可分离峰、位置重叠（中心靠得很近）
  (c) 不可分离峰（旋转的椭圆高斯），位置分开
显著分量：e_i > 1.15 * MP 上沿，MP 上沿 = sigma^2 (sqrt(m)+sqrt(n))^2（sigma 已知；真实数据里是估计量，是局限）。
"""
import numpy as np

rng = np.random.default_rng(11)
m = n = 100
SIGMA = 0.01
EDGE = SIGMA ** 2 * (np.sqrt(m) + np.sqrt(n)) ** 2
I, J = np.meshgrid(np.arange(m), np.arange(n), indexing="ij")


def separable(ci, cj, s=4.0):
    return np.exp(-((I - ci) ** 2 + (J - cj) ** 2) / (2 * s ** 2))


def rotated(ci, cj, s_major=12.0, s_minor=3.0, theta=np.pi / 4):
    x, y = I - ci, J - cj
    u = np.cos(theta) * x + np.sin(theta) * y
    v = -np.sin(theta) * x + np.cos(theta) * y
    return np.exp(-(u ** 2 / (2 * s_major ** 2) + v ** 2 / (2 * s_minor ** 2)))


def count_significant(X):
    s = np.linalg.svd(X, compute_uv=False)
    e = s ** 2
    return int(np.sum(e > 1.15 * EDGE)), e


def run(name, X_clean, n_peaks):
    X = X_clean + SIGMA * rng.standard_normal((m, n))
    k, e = count_significant(X)
    top = " ".join(f"{x:.3g}" for x in e[:6])
    print(f"[{name}] 峰数 N={n_peaks}；显著分量 {k} 个；噪声上沿 {EDGE:.3f}；前 6 个 e = {top}")
    return k


def main():
    a = separable(20, 30) + separable(50, 70) + separable(80, 20)
    b = separable(46, 46) + separable(50, 50) + separable(54, 54)
    c = rotated(20, 30) + rotated(50, 70) + rotated(80, 20)
    ka = run("(a) 可分离、分开", a, 3)
    kb = run("(b) 可分离、重叠", b, 3)
    kc = run("(c) 不可分离（旋转椭圆）、分开", c, 3)
    print()
    print(f"显著分量数 / 峰数：(a) {ka}/3，(b) {kb}/3，(c) {kc}/3")


if __name__ == "__main__":
    main()
